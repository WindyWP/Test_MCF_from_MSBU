﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Data;
using System.Data.SqlClient;
using System.Text.Json.Serialization;
using WebAPI_Core_MVC.Models;

namespace WebAPI_Core_MVC.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class tr_bpkbController : ControllerBase
    {
        private readonly IConfiguration _configuration;

        public tr_bpkbController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpGet]
        [Route("GetAlltrbpkb")]     
        public string  Gettrbpkb()
        {
            SqlConnection con = new SqlConnection(_configuration.GetConnectionString("trbpkbAppCon").ToString());
            SqlDataAdapter da = new SqlDataAdapter("SELECT * From tr_bpkb", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            List<tr_bpkb> trbpkblist = new List<tr_bpkb>();
            Response response = new Response();
            if(dt.Rows.Count > 0) 
            {
                for(int i=0; i<dt.Rows.Count; i++)
                {
                    tr_bpkb tr_Bpkb = new tr_bpkb();
                    tr_Bpkb.agreagreement_number = Convert.ToString(dt.Rows[i]["agreagreement_number"]);
                    tr_Bpkb.bpkb_no = Convert.ToString(dt.Rows[i]["bpkb_no"]);
                    tr_Bpkb.branch_id = Convert.ToString(dt.Rows[i]["branch_id"]);
                    tr_Bpkb.bpkb_date = Convert.ToDateTime(dt.Rows[i]["bpkb_date"]);
                    tr_Bpkb.faktur_no = Convert.ToString(dt.Rows[i]["faktur_no"]);
                    tr_Bpkb.faktur_date = Convert.ToDateTime(dt.Rows[i]["faktur_date"]);
                    tr_Bpkb.location_id = Convert.ToString(dt.Rows[i]["location_id"]);
                    tr_Bpkb.police_no = Convert.ToString(dt.Rows[i]["police_no"]);
                    tr_Bpkb.bpkb_date_in = Convert.ToDateTime(dt.Rows[i]["bpkb_date_in"]);
                    trbpkblist.Add(tr_Bpkb);
                }
            }
            
            if(trbpkblist.Count > 0)
                return JsonConvert.SerializeObject(trbpkblist);
            else
            {
                response.StatusCode = 100;
                response.ErrorMessage = "Data not Found";
                return JsonConvert.SerializeObject(response);  
            }
        }
     
    }
}
