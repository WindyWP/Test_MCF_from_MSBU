﻿namespace WebAPI_Core_MVC.Models
{
    public class Response
    {
        public int StatusCode { get; set; }
        public string ErrorMessage { get; set; }    
    }
}
